package template;

import mindustry.mod.*;
import template.gen.*;

public class ModTemplate extends Mod{
    @Override
    public void loadContent(){
        EntityRegistry.register();
    }
}
